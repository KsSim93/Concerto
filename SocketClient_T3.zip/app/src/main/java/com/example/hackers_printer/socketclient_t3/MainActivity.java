package com.example.hackers_printer.socketclient_t3;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import android.os.Handler;
import android.os.Message;

import java.util.TimerTask;


import org.w3c.dom.Text;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;


public class MainActivity extends AppCompatActivity {

    private String ip="203.252.22.161";
    private int port = 8081;
    private Socket socket;
    TextView text_msg;

    DataOutputStream os;
    DataInputStream is;



    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            text_msg=(TextView)findViewById(R.id.text_massage_from_server);
        text_msg.setText("Coffee");
            handler.sendEmptyMessage(0);
        }

        //매 1초 마다 증가할 정수값



    //타이머를 처리하기 위해 핸들러 객체 생성
    private Handler handler = new Handler() {
        String msgs="";
        public void handleMessage(Message msg) {


            new Thread(new Runnable() {

                @Override
                public void run() {
                    // TODO Auto-generated method stub
                    try {
                        msgs+="connect!!!";
                        //서버와 연결하는 소켓 생성..
                        socket= new Socket(ip, port);
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                // TODO Auto-generated method stub
                                text_msg.setText(msgs);
                            }

                        });



                            //여기까지 왔다는 것을 예외가 발생하지 않았다는 것이므로 소켓 연결 성공..
                        //서버와 메세지를 주고받을 통로 구축
                        is=new DataInputStream(socket.getInputStream());
                        os=new DataOutputStream(socket.getOutputStream());

                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        msgs+="False";
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                // TODO Auto-generated method stub
                                text_msg.setText(msgs);
                            }

                        });
                        e.printStackTrace();
                    }

                    //서버와 접속이 끊길 때까지 무한반복하면서 서버의 메세지 수신
              //      while(true){
                    msgs += "while";
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                // TODO Auto-generated method stub
                                text_msg.setText(msgs);
                            }

                        });
                        try {
                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
                            byte[] buffer = new byte[1024];
                            int bytesRead;
                            InputStream inputStream = socket.getInputStream();

                            while ((bytesRead = inputStream.read(buffer)) != -1) {
                                byteArrayOutputStream.write(buffer, 0, bytesRead);
                                msgs= byteArrayOutputStream.toString("UTF-8");
                            }
                           /* msgs= is.readUTF(); //서버 부터 메세지가 전송되면 이를 UTF형식으로 읽어서 String 으로 리턴
                            runOnUiThread(new Runnable() {

                                @Override
                                public void run() {
                                    // TODO Auto-generated method stub
                                    text_msg.setText("try");
                                }

                            });*/
                            //서버로부터 읽어들인 메시지msg를 TextView에 출력..
                            //안드로이드는 오직 main Thread 만이 UI를 변경할 수 있기에
                            //네트워크 작업을 하는 이 Thread에서는 TextView의 글씨를 직접 변경할 수 없음.
                            //runOnUiThread()는 별도의 Thread가 main Thread에게 UI 작업을 요청하는 메소드임.
                            runOnUiThread(new Runnable() {

                                @Override
                                public void run() {
                                    // TODO Auto-generated method stub
                                    text_msg.setText(msgs);
                                }

                            });
                            //////////////////////////////////////////////////////////////////////////
                          //  msgs="";
                        } catch (IOException e) {
                            msgs+="catch";
                            runOnUiThread(new Runnable() {

                                @Override
                                public void run() {
                                    // TODO Auto-generated method stub
                                    text_msg.setText(msgs);
                                }

                            });
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }

               //     }//while

                }//run method...
            }).start();//Thread 실행..
            //1초간의 지연 시간을 두어 1초후에 자기자신이 호출 되도록 한다.
            handler.sendEmptyMessageDelayed(0, 4000);
        }
    };


}



       /*final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //지연시키길 원하는 밀리초 뒤에 동작

            }
        }, 5000 );
*/



  /*      new Thread(new Runnable() {

            @Override
            public void run() {
                // TODO Auto-generated method stub
                try {

                    //서버와 연결하는 소켓 생성..
                    socket= new Socket(ip, port);


                    //여기까지 왔다는 것을 예외가 발생하지 않았다는 것이므로 소켓 연결 성공..
                    //서버와 메세지를 주고받을 통로 구축
                    is=new DataInputStream(socket.getInputStream());
                    os=new DataOutputStream(socket.getOutputStream());

                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

                //서버와 접속이 끊길 때까지 무한반복하면서 서버의 메세지 수신
                while(true){
                    try {
                        msg= is.readUTF(); //서버 부터 메세지가 전송되면 이를 UTF형식으로 읽어서 String 으로 리턴

                        //서버로부터 읽어들인 메시지msg를 TextView에 출력..
                        //안드로이드는 오직 main Thread 만이 UI를 변경할 수 있기에
                        //네트워크 작업을 하는 이 Thread에서는 TextView의 글씨를 직접 변경할 수 없음.
                        //runOnUiThread()는 별도의 Thread가 main Thread에게 UI 작업을 요청하는 메소드임.
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                // TODO Auto-generated method stub
                                text_msg.setText(msg);
                            }
                        });
                        //////////////////////////////////////////////////////////////////////////

                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }//while
            }//run method...
        }).start();//Thread 실행..
*/